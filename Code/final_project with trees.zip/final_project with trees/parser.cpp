//
//  parser.cpp
//  
//
//  Created by Hadi Zayer on 7/19/15.
//
//

#include "parser.h"
#include <fstream>
#include <iostream>
#include <OpenGL/gl.h>
#include "GLUT/glut.h"
#include <math.h>
#include <vector>
#include <string>

void Data::loadFile(std::string fileName) {
    std::ifstream input(fileName);
    
    if (input.fail()) {
        std::cerr << "ERROR: Can't load file" << std::endl;
        exit(1);
    }
    
    std::string s;
    float x, y, z;
    int a, b, c;
    int at, bt, ct;
    int an, bn, cn;
    while (!input.eof()) {
        input >> s;
//        if(s == 'v'){
//            input >> x;
//            input >> y;
//            input >> z;
//            std::cout << x << std::endl;
//        }
//    }
        if (s == "v"){
                input >> x;
                input >> y;
                input >> z;
                points.push_back(point(x, y, z));
        }
        
        else if(s == "f"){
                if(!normals.empty()){
                    input >> a;
                    input.ignore(1, '/');
                    input >> at;
                    input.ignore(1, '/');
                    input >> an;
                    input >> b;
                    input.ignore(1, '/');
                    input >> bt;
                    input.ignore(1, '/');
                    input >> bn;
                    input >> c;
                    input.ignore(1, '/');
                    input >> ct;
                    input.ignore(1, '/');
                    input >> cn;
                    triangles.push_back(triangle(points[a - 1], uv[at - 1], normals[an - 1],points[b - 1],  uv[bt - 1], normals[bn - 1], points[c - 1], uv[ct - 1], normals[cn - 1]));
                }
                
                else if(!uv.empty()){
                    input >> a;
                    input >> at;
                    input >> b;
                    input >> bt;
                    input >> c;
                    input >> ct;
                    triangles.push_back(triangle(points[a - 1], uv[at - 1], points[b - 1],  uv[bt - 1], points[c - 1], uv[ct - 1]));
                }
                
                else {
                    input >> a;
                    input >> b;
                    input >> c;
                    triangles.push_back(triangle(points[a - 1], points[b - 1], points[c - 1]));
                }
            }

        else if(s == "vt"){
                input >> x;
                input >> y;
                uv.push_back(point(x, y, 0));
            }
        
        else if(s == "vn"){
                input >> x;
                input >> y;
                input >> z;
                normals.push_back(point(x, y, z));
                }
        else if(s == "#"){
                input.ignore(500, '\n');
        }        
    }
//    for (int i = 0; i < points.size(); i++) {
//        std::cout << points[i].x << " " << points[i].y << " " << points[i].z << std::endl;
//    }
    std::cout << "FINISHED LOADING" << std::endl;
}

void Data::render(){
    glColor3f(1, 0, 0);
    if (!uv.empty()) {
        glBegin(GL_TRIANGLES);
        for (int i = 0; i < triangles.size(); i++) {
            glTexCoord2f(triangles[i].at.x, triangles[i].at.y);
            glNormal3f(triangles[i].an.x, triangles[i].an.y, triangles[i].an.z);
            glVertex3f(triangles[i].a.x, triangles[i].a.y, triangles[i].a.z);
            glTexCoord2f(triangles[i].bt.x, triangles[i].bt.y);
            glNormal3f(triangles[i].bn.x, triangles[i].bn.y, triangles[i].bn.z);
            glVertex3f(triangles[i].b.x, triangles[i].b.y, triangles[i].b.z);
            glTexCoord2f(triangles[i].ct.x, triangles[i].ct.y);
            glNormal3f(triangles[i].cn.x, triangles[i].cn.y, triangles[i].cn.z);
            glVertex3f(triangles[i].c.x, triangles[i].c.y, triangles[i].c.z);
        }
        glEnd();
    }
    else {
    glBegin(GL_TRIANGLES);
        for (int i = 0; i < triangles.size(); i++) {
            point u = point(triangles[i].b.x - triangles[i].a.x, triangles[i].b.y - triangles[i].a.y, triangles[i].b.z - triangles[i].a.z);
            point v = point(triangles[i].c.x - triangles[i].a.x, triangles[i].c.y - triangles[i].a.y, triangles[i].c.z - triangles[i].a.z);
            
            point normal = point(u.y * v.z - u.z * v.y, u.z * v.x - u.x * v.z, u.x * v.y - u.y * v.x);
            float normalMagnitude = sqrt(pow(normal.x,2)+ pow(normal.y,2) + pow(normal.z,2));
            normal = point(normal.x/normalMagnitude, normal.y/normalMagnitude, normal.z/normalMagnitude);
            glNormal3f(normal.x, normal.y, normal.z);
            
            glVertex3f(triangles[i].a.x, triangles[i].a.y, triangles[i].a.z);
            glVertex3f(triangles[i].b.x, triangles[i].b.y, triangles[i].b.z);
            glVertex3f(triangles[i].c.x, triangles[i].c.y, triangles[i].c.z);
        }
        glEnd();
    }
}