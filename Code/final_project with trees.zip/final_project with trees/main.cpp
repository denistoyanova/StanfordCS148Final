
#include "main.h"
#ifdef WIN32
#define ssize_t SSIZE_T
#endif

#include <vector>
#include <iostream>
#include <fstream>
#include <string>
#include <cstdio>
#include <cmath>
#include "SimpleImage.h"
#include "SimpleShaderProgram.h"
#include "parser.h"

#define PI 3.14159265
//landscape size needs to be a power of 2 + 1
#define LANDSCAPE_SIZE 129
#define CORNER_1 0
#define CORNER_2 50
#define CORNER_3 0
#define CORNER_4 0

void Setup();

bool renderTree = true;


// Define Global text structure
static GLuint texName;
static GLuint treeTexName;
int width, height;

// Define Global Variables for movement
GLfloat Y_MOVEMENT = 0, X_MOVEMENT = 0, Z_MOVEMENT = 0;

// file locations
std::string vertexShader;
std::string fragmentShader;
std::string OBJ_file;

SimpleShaderProgram *shader;
SimpleShaderProgram *treeShader;

Data data;

std::vector< std::vector<float> > landscape(LANDSCAPE_SIZE, std::vector<float>(LANDSCAPE_SIZE));

int cam_x = 0, cam_y = 0, xo = 0, yo = 0;
float red = 0.5, green = 0.5, blue = 0.5;

struct Vector3{
    float x,y,z;
    Vector3(float _x, float _y, float _z){
        x = _x; y = _y; z = _z;
    }
    Vector3(){
        x = 0; y = 0; z = 0;
    }
    Vector3 operator-(Vector3 v){
        return Vector3(x - v.x, y - v.y, z - v.z);
    }
    Vector3 operator+(Vector3 v){
        return Vector3(x + v.x, y + v.y, z + v.z);
    }
};

Vector3 cross(Vector3 v1, Vector3 v2){
    return Vector3(v1.y * v2.z - v1.z * v2.y, v1.z * v2.x - v1.x * v2.z, v1.x * v2.y - v1.y * v2.x);
}

Vector3 normalize(Vector3 v){
    float length = sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
    return Vector3(v.x / length, v.y / length, v.z / length);
}

Vector3 normal[LANDSCAPE_SIZE][LANDSCAPE_SIZE];

void getLandNormal(){
    for(int i = 1; i < LANDSCAPE_SIZE - 1; i++){
        for(int j = 1; j < LANDSCAPE_SIZE - 1; j++){
            Vector3 deltaX = Vector3(float(i + 1), float(j), landscape[i+1][j]) - Vector3(float(i -1), float(j), landscape[i-1][j]);
            Vector3 deltaY = Vector3(float(i), float(j+1), landscape[i][j+1]) - Vector3(float(i), float(j-1), landscape[i][j-1]);
            normal[i][j] = normalize(cross(deltaX, deltaY));
            
        }
    }
    for(int j = 1; j < LANDSCAPE_SIZE - 1; j++){
        normal[0][j] = normal[1][j];
        normal[LANDSCAPE_SIZE - 1][j] = normal[LANDSCAPE_SIZE - 2][j];
    }
    for(int i = 0; i < LANDSCAPE_SIZE; i++){
        normal[i][0] = normal[i][1];
        normal[i][LANDSCAPE_SIZE-1] = normal[i][LANDSCAPE_SIZE-2];
    }
    return;
}

float getSquareValue(int x, int y, int size) {
    return (landscape[x - size][y - size] +
        landscape[x - size][y + size] +
        landscape[x + size][y - size] +
        landscape[x + size][y + size])/4;
}

int mod(int a, int b)
{
    if (a == b) return a;
    return (a%b+b)%b;
}



float getDiamondValue(int x, int y, int size) {
    printf("%d,%d\n", mod(x + size,landscape.size()-1),y);
    printf("%d,%d\n", mod(x - size,landscape.size()-1),y);
    printf("%d,%d\n", x, mod(y + size,landscape.size()-1));
    printf("%d,%d\n\n\n", x, mod(y - size,landscape.size()-1));

    return (landscape[mod(x + size, landscape.size()-1)][y] + 
        landscape[mod(x - size, landscape.size()-1)][y] + 
        landscape[x][mod(y + size, landscape.size()-1)] + 
        landscape[x][mod(y - size, landscape.size()-1)])/4; 
}

void generateLandscape() {
    int size = landscape.size() - 1;

    landscape[landscape.size()-1][landscape.size()-1] = CORNER_4;
    landscape[0][landscape.size()-1] = CORNER_3;
    landscape[landscape.size()-1][0] = CORNER_2;
    landscape[0][0] = CORNER_1;

    for (int depth = 1; size/depth > 1; depth*=2) {
        for (int xd = 0; xd < depth; xd++) {
            for (int yd = 0; yd < depth; yd++) {
                int x = size/(depth*2) + xd*size/depth;
                int y = size/(depth*2) + yd*size/depth;
                landscape[x][y] = getSquareValue(x,y,size/(depth*2));
                printf("center:%d,%d,%f\n", x,y, landscape[x][y]);
            }
        }

        for (int xd = 0; xd < depth; xd++) {
            for (int yd = 0; yd < depth; yd++) {

                int x = size/(depth*2) + xd*size/depth;
                int y = size/(depth*2) + yd*size/depth;

                int x_edge, y_edge;
                x_edge = x - size/(depth*2);
                y_edge = y;
                landscape[x_edge][y_edge] = getDiamondValue(x_edge, y_edge, size/(depth*2));
                printf("edge:%d,%d,%f\n", x_edge,y_edge,landscape[x_edge][y_edge]);

                x_edge = x + size/(depth*2);
                y_edge = y;
                landscape[x_edge][y_edge] = getDiamondValue(x_edge, y_edge, size/(depth*2));
                printf("edge:%d,%d,%f\n", x_edge,y_edge,landscape[x_edge][y_edge]);

                x_edge = x;
                y_edge = y - size/(depth*2);
                landscape[x_edge][y_edge] = getDiamondValue(x_edge, y_edge, size/(depth*2));
                printf("edge:%d,%d,%f\n", x_edge,y_edge,landscape[x_edge][y_edge]);

                x_edge = x;
                y_edge = y + size/(depth*2);
                landscape[x_edge][y_edge] = getDiamondValue(x_edge, y_edge, size/(depth*2));
                printf("edge:%d,%d,%f\n", x_edge,y_edge,landscape[x_edge][y_edge]);

            }
        }
    }

}


void click(int button, int button_state, int x, int y)
{
    xo = x;
    yo = y;
}

void pan(int x, int y)
{
    cam_y = (cam_y + (y - yo)) % 360;
    cam_x = (cam_x + (x - xo)) % 360;
    xo = x;
    yo = y;
    glutPostRedisplay();
}

float getMax(int a, int b, int c, int d){

    return (float)std::max(std::max(a,b), std::max(c,d));

}

void DrawWithShader(){
    
    shader -> Bind();
    shader -> SetUniform("max_height", getMax(CORNER_1,CORNER_2,CORNER_3,CORNER_4));

    // enable fod
    GLfloat fog_color[] = {0.5f,0.5f,0.5f,1};
    glFogfv(GL_FOG_COLOR, fog_color);
    glFogf(GL_FOG_DENSITY, 0.001f);

    // Enable Texturing
    glEnable(GL_TEXTURE_2D);

    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
   
    vertexShader = "final.vert";
    fragmentShader = "final.frag";
    Setup();

    for (int x = 0; x < landscape.size() - 1; x++) {
        for (int y = 0; y < landscape.size() - 1; y++) {
            glBindTexture(GL_TEXTURE_2D, texName);
            std::cout << landscape[x][y] << std::endl;
            shader -> SetUniform("height", landscape[x][y]);
            
            glBegin(GL_POLYGON);

                glNormal3f(normal[x][y].x, normal[x][y].y, normal[x][y].z);
                glTexCoord2f(float(x),float(y));
                glVertex3f(float(x), float(y), landscape[x][y]);
    
                glNormal3f(normal[x+1][y].x, normal[x+1][y].y, normal[x+1][y].z);
                glTexCoord2f(float(x+1),float(y));
                glVertex3f(float(x+1), float(y), landscape[x+1][y]);
    
                glNormal3f(normal[x][y+1].x, normal[x][y+1].y, normal[x][y+1].z);
                glTexCoord2f(float(x),float(y+1));
                glVertex3f(float(x), float(y+1), landscape[x][y+1]);
            glEnd();

            glBegin(GL_POLYGON);

                glNormal3f(normal[x+1][y+1].x, normal[x+1][y+1].y, normal[x+1][y+1].z);
                glTexCoord2f(float(x+1),float(y+1));
                glVertex3f(float(x+1), float(y+1), landscape[x+1][y+1]);

                glNormal3f(normal[x+1][y].x, normal[x+1][y].y, normal[x+1][y].z);
                glTexCoord2f(float(x+1),float(y));
                glVertex3f(float(x+1), float(y), landscape[x+1][y]);

                glNormal3f(normal[x][y+1].x, normal[x][y+1].y, normal[x][y+1].z);
                glTexCoord2f(float(x),float(y+1));
                glVertex3f(float(x), float(y+1), landscape[x][y+1]);
            glEnd();
        }
        
    }
    shader->UnBind();

    vertexShader = "tree.vert";
    fragmentShader = "tree.frag";
    
    treeShader = new SimpleShaderProgram();
    treeShader->LoadVertexShader(vertexShader);
    treeShader->LoadFragmentShader(fragmentShader);
    treeShader->Bind();

    for (int x = 0; x < landscape.size() - 1; x++) {
        for (int y = 0; y < landscape.size() - 1; y++) {
            if (x % 15 == 0 && y % 15 == 0 && (x > 5 && y > 5) && landscape[x][y] < 30 && renderTree) {
                glBindTexture(GL_TEXTURE_2D, treeTexName);
                SimpleImage texPNG("treeTex.jpg");
                width = texPNG.width();
                height = texPNG.height();
                
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_FLOAT, texPNG.data());
                glGenerateMipmap(GL_TEXTURE_2D);
                
                glPushMatrix();
                glTranslatef(x, y, landscape[x][y]);
                glRotatef(90,1,0,0);
                data.render();
                glPopMatrix();
            }
        }

    }

    treeShader->UnBind();
}

void DisplayCallback(){
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(-11., -11, 6, landscape.size()/2, landscape.size()/2, 0, 0.0, 0.0, 1.0);
    glRotatef((GLfloat) cam_x, 0.0, 0.0, 1.0);
    glTranslatef(X_MOVEMENT,Y_MOVEMENT,Z_MOVEMENT);

    // set up the texture
    glGenTextures(1, &texName);
    glBindTexture(GL_TEXTURE_2D, texName);
    
    glGenTextures(2, &treeTexName);

    // glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);

    SimpleImage texPNG("noise.png"); 
    width = texPNG.width();
    height = texPNG.height();

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_FLOAT, texPNG.data());
    glGenerateMipmap(GL_TEXTURE_2D);

    DrawWithShader();
    
    glutSwapBuffers();
}

void ReshapeCallback(int w, int h){
    glViewport(0, 0, w, h);

    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    gluPerspective(30.0f, (float)w/(float)h, 0.1f, 100000.f);

}

// Set up the program for rendering
void Setup()
{
    // load the shaders
    shader = new SimpleShaderProgram();
    shader->LoadVertexShader(vertexShader);
    shader->LoadFragmentShader(fragmentShader);

    // clear te screen to black and enable depth testing
    glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
    glEnable(GL_FOG);
    glEnable(GL_DEPTH_TEST);

    // set up the lighting properties
    GLfloat light_color[] = {1, 1, 1, 1};
    GLfloat light_pos[] = {25, 25, 10, 1}; 
    glLightfv(GL_LIGHT0, GL_AMBIENT, light_color); 
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_color); 
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_color); 
    glLightfv(GL_LIGHT0, GL_POSITION, light_pos); 

    // set the material properties
    GLfloat specular[] = { 1, 1, 1, 1.0 };
    glMaterialfv(GL_FRONT,GL_SPECULAR,specular);
    glMaterialf(GL_FRONT,GL_SHININESS,30);

}

// Define the special keyboard functions
// The arrow keys move the object around
void SpecialKeyboardInput(int key, int x, int y)
{
    switch(key)
    {
        case GLUT_KEY_UP:                   // up key - move object up
            Y_MOVEMENT = Y_MOVEMENT - 5;
            break;
        case GLUT_KEY_DOWN:                 // down key - move object down
            Y_MOVEMENT = Y_MOVEMENT + 5;
            // glutPostRedisplay();
            break;
        case GLUT_KEY_LEFT:                 // left key - move object left
            X_MOVEMENT = X_MOVEMENT + 5;
            //glutPostRedisplay();
            break;
        case GLUT_KEY_RIGHT:                // right key - move object right
            X_MOVEMENT = X_MOVEMENT - 5;
            //glutPostRedisplay();
            break;
    }
    glutPostRedisplay();
    
}

void KeyCallback(unsigned char key, int x, int y)
{
    switch(key) {
    case 'q':
        exit(0);
    case 'i' :                   // i key - zoom object closer in
        Z_MOVEMENT = Z_MOVEMENT + 2.0;
        break;
    case 'o':                    // o key - zoom object farther out
        Z_MOVEMENT = Z_MOVEMENT - 2.0;
        break;
    case 't':
            renderTree = !renderTree;
            break;
    default:
        break;
    }

    glutPostRedisplay();
}


int main(int argc, char** argv){
    if(!(argc == 3)){
        printf("usage: ./main <vertex shader> <fragment shader> \n");
        return 0;
    }

    vertexShader   = std::string(argv[1]);
    fragmentShader = std::string(argv[2]);
    
    data = Data();
    data.loadFile("tree.obj");
    
    // Initialize GLUT.
    glutInit(&argc, argv);
    glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowPosition(20, 20);
    glutInitWindowSize(640, 480);
    glutCreateWindow("CS148 Assignment Final Project");

    generateLandscape();
    getLandNormal();

    Setup();

    glutDisplayFunc(DisplayCallback);
    glutReshapeFunc(ReshapeCallback);

    glutKeyboardFunc(KeyCallback);
    glutSpecialFunc(SpecialKeyboardInput);
    glutMouseFunc(click);
    glutMotionFunc(pan);

    glutMainLoop();
    return 0;
}

