//
//  parser.h
//  
//
//  Created by Hadi Zayer on 7/19/15.
//
//

#ifndef ____parser__
#define ____parser__

#include <stdio.h>
#include <vector>
#include <string>

struct point {
    float x, y, z;
   
    point(){
        x = 0.0;
        y = 0.0;
        z = 0.0;
    }

    point(float _x, float _y, float _z){
        x = _x;
        y = _y;
        z = _z;
    }
};

struct triangle{
    point a, b, c;
    point at, bt, ct;
    point an, bn, cn;
    
    triangle(){
        a = point();
        b = point();
        c = point();
        at = point();
        bt = point();
        ct = point();
        an = point();
        bn = point();
        cn = point();
    }
    
    triangle(point _a, point _b, point _c){
        a = _a;
        b = _b;
        c = _c;
        at = point();
        bt = point();
        ct = point();
        an = point();
        bn = point();
        cn = point();
    }
    
    triangle(point _a, point _at, point _b, point _bt, point _c, point _ct){
        a = _a;
        b = _b;
        c = _c;
        at = _at;
        bt = _bt;
        ct = _ct;
        an = point();
        bn = point();
        cn = point();
    }
    
    triangle(point _a, point _at, point _an, point _b, point _bt, point _bn, point _c, point _ct, point _cn){
        a = _a;
        b = _b;
        c = _c;
        at = _at;
        bt = _bt;
        ct = _ct;
        an = _an;
        bn = _bn;
        cn = _cn;
    }
};

class Data{
public:
    std::vector<point> points;
    std::vector<triangle> triangles;
    
    std::vector<point> uv;
    std::vector<point> normals;

    void render();
    void loadFile(std::string fileName);
};

#endif /* defined(____parser__) */
